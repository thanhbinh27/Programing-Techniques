class ClassName {
    constructor() {
        //...
    }
}
console.log(ClassName);