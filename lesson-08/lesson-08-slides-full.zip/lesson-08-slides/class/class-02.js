class Car {
    constructor(name, year) {
        this.name = name;
        this.year = year;
    }
}

let carA = new Car();
console.log(carA);

let carB = new Car("Ford", 2014);
console.log(carB);