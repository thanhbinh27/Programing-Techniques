class Student {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
}
let studentA = new Student('Hiếu Đặng', 18);
console.log(studentA);
console.log(studentA.name);
console.log(studentA.age);