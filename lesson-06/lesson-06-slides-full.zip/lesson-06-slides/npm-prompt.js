//npm i prompt-sync
var prompt = require('prompt-sync')();

var n = prompt('How many hours does your class take? ');
console.log(n);