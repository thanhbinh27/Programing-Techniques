// npm i js-alert
var jsAlert = require("js-alert");

jsAlert.alert("Xin chào VUSers!");