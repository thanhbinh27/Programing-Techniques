var arr = [6, 9, 1, 8];
var n = arr.length;
console.log(n);
console.log(arr);
console.log("---");

function deleteLast() {
    arr.length--;
    n--;
}

deleteLast();
console.log(n);
console.log(arr);