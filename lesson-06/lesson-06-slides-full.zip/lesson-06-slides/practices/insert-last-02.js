// let students = ['Tý', 'Tèo', 'Tồ'];
// let n = students.length;
// console.log(students);

// function insertLast(student) {
//     students[n] = student;
//     n++;
// }

// insertLast('An');
// console.log(students);

let phone = ['iphone', 'samsung', 'vivo', ' oppo'];
var n = phone.length;
var x = 'Bphone';

console.log(phone);

function insertLast(x) {
    phone[n] = x;
    n++;
}

insertLast(x);

console.log(phone);