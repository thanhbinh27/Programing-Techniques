// Cách 1:
var carA = {
    name: "BMW",
    color: "black",
    capacity: 4
}
console.log(carA);

// Cách 2:
var carB = new Object();
carB.name = "Audi";
carB.color = "red";
carB.capacity = 6;
console.log(carB);