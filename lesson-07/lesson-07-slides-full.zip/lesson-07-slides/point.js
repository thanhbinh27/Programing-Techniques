// Cách 1:
var pointA = {
    x: 0,
    y: 0
}
console.log(pointA);

// Cách 2:
var pointB = new Object();
pointB.Ox = 0;
pointB.Oy = 0;
console.log(pointB);