let fruits = ["Apple", "Orange", "Plum"];
console.log(fruits[0]); // "Apple"
console.log(fruits[1]); // "Orange"
console.log(fruits[2]); // "Plum"