var user = {
    name: "Teo",
    age: 20
};

console.log(Object.keys(user)); // ['name', 'age']
console.log(Object.values(user)); // ['Teo', 20]
console.log(Object.entries(user)); // [['name', 'Teo'], ['age', 20]]