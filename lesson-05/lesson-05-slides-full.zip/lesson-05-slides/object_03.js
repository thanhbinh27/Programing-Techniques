var name = "Teo";

var emptyObject = {};
console.log(emptyObject); // {}