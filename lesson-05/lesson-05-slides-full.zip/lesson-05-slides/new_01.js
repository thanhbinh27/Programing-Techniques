var emptyObject = new Object();
console.log(emptyObject); // {}