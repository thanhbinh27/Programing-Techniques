let fruits = ["Apple", "Orange", "Plum"];
console.log(fruits[3]); // undefine
fruits[3] = "Lemon";
console.log(fruits[3]); // "Lemon"