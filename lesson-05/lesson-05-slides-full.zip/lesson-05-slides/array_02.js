var arr = [
    "hello world",
    18,
    true
];
arr[0]; // "hello world"
arr[1]; // 18
arr[2]; // true
arr.length; // 3
typeof arr; // "object"

console.log(typeof arr);