var box = { name: "Minh Dao" };
typeof box; // "object"
console.log(typeof box);