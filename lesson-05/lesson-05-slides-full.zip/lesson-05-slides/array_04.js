let fruits = ["Apple", "Orange", "Plum"];
console.log(fruits[2]); // "Plum"
fruits[2] = "Pear";
console.log(fruits[2]); // "Pear"