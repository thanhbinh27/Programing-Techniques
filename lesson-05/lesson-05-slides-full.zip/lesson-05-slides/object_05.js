var user = {
    name: "Teo",
    age: 18,
    sayHello: function() {
        console.log("Hello World!");
    }
};
user.sayHello(); //Hello World!