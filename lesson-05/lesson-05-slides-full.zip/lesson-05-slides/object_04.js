let user = {
    name: "Teo",
    age: 18
};
console.log(user); //{ name: 'Teo', age: 18 }