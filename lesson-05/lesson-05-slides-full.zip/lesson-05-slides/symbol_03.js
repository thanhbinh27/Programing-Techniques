console.log(Symbol()); // Symbol()
console.log(Symbol('Name')); //Symbol(Name)