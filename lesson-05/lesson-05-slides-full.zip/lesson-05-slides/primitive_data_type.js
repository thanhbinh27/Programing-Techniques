let a = 1;
let b = a;
// console.log(a); //1
// console.log(b); //1

b = 2;
console.log(a); //1
console.log(b); //2